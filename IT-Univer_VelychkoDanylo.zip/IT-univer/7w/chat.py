import socket
import threading
import select

class ReadThread(threading.Thread):
    def __init__(self,sock):
        threading.Thread.__init__(self)
        self.sock=sock

    def run(self):
        while(True):
            message=self.sock.recv(1024).decode()
            print(message)



def main():
    sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.connect(('127.0.0.1', 55558))
    select.select([sock],[sock],[])#при ошибке сокета, сокет будет закрыт.
    read_thread=ReadThread(sock)
    read_thread.start()
    while(True):
        message=input()
        sock.send(message.encode())

main()
