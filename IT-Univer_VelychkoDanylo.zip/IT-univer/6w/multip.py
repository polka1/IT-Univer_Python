#DZ сумма чисел 1-10 000 000, считать до 10 потоков + время выполнения программы
# #сисмитричная мультипроцессорная архитектура
#Numa - кластерная архитектура (мэинфрейм - дорогая шина)
#ПАТЕРН:  Производитель - потребитель
#ПАТЕРН:  Produser - Consumer
#mutex - флажок (объект синхронизации)
import threading
import datetime
class sum(threading.Thread):
    def __init__(self,begin,end):
        threading.Thread.__init__(self)
        self.begin=begin
        self.end=end
        self.result=0


    def run(self):
        for i in range(self.begin,self.end):
            self.result+=i

def main():
    d=datetime.datetime.now()
    s1=sum(1,50000)
    s2=sum(50000,100001)
    s1.start() #асинхронен.
    s2.start() #
    s1.join()
    s2.join()
    total=s1.result+s2.result
    d2=datetime.datetime.now()

    print(total)
    print(d2-d)

main()