import socket
import threading

class ClientHandler(threading.Thread):
    def __init__(self,client_sock,client_map):
        threading.Thread.__init__(self)
        self.client_sock=client_sock
        self.client_map=client_map

    def run(self):
        registration_message=self.client_sock.recv(1024).decode()
        registr=registration_message.split(":")
        name=registr[1]
        self.client_map[name]=self.client_sock
        while(True):
            message=self.client_sock.recv(1024).decode()
            split_message=message.split(":")
            if(split_message[0]=='list'):
                list_clients=self.client_map.keys()
                output=""
                for name in list_clients:
                    output+=name+"\n"

                self.client_sock.send(output.encode())
            elif(split_message[0]=='broadcast'):
                list_socks=self.client_map.values()
                for sock in list_socks:
                    sock.send(split_message[1].encode())
            else:
                name=split_message[0]
                sock=self.client_map[name]
                sock.send(split_message[1].encode)



def main():
    serv_sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    serv_sock.bind(('0.0.0.0', 55558))
    serv_sock.listen(6)#backlog
    client_map={}


    while(True):
        client_sock,addr=serv_sock.accept()
        client_thread=ClientHandler(client_sock,client_map)
        client_thread.start()

main()