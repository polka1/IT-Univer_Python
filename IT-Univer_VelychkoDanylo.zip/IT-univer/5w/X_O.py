class Game:
    def __init__(self,player1,player2):
        self.player1=player1
        self.player2=player2

    def startGame(self):
        while (True):
            self.player1.step()
            if (self.player1.isWinner()):
                print('Player1 is winner ')
                return

            self.player2.step()
            if(self.player2.isWinner()):
                print('Player2 is winner')
                return

class Player:
    def __init__(self,field,symbol):
        self.field=field
        self.symbol=symbol

    def step(self):
        pass

    def isWinner(self):
        return self.field.isWinnerCombination(self.symbol)

class Human(Player):
    def __init__(self,field,symbol):
        Player.__init__(self,field,symbol)

    def step(self):
        while True:
            print('______________')
            x=int(input('Input X coord: '))
            print('______________')
            y=int(input('Input Y coord: '))
            if self.field.isEmpty(x, y):
                self.field.putSymbol(x,y,self.symbol)
                self.field.show()
                return

class Computer(Player):
    def __init__(self,field,symbol):
        Player.__init__(self,field,symbol)

    def step(self):
        coords=self.field.randomEmptyCell()
        self.field.putSymbol(coords[0],coords[1],self.symbol)
        self.field.show()

class Field:
    def __init__(self):
        self.cells=[]
        for i in range(0,3):
            temp=[]
            for j in range(0,3):
                temp.append(Cell())
            self.cells.append(temp)

    def isWinnerCombination(self,symbol):
        if(self.cells[0][0].value==symbol):
            if(self.cells[1][0].value==self.cells[0][0].value and self.cells[2][0].value==self.cells[0][0].value):
                return True
            if(self.cells[0][1].value==self.cells[0][0].value and self.cells[0][2].value==self.cells[0][0].value):
                return True
            if(self.cells[1][1].value==self.cells[0][0].value and self.cells[2][2].value==self.cells[0][0].value):
                return True
        if (self.cells[0][1].value==symbol):
            if (self.cells[1][1].value==self.cells[0][1].value and self.cells[2][1].value==self.cells[0][1].value):
                return True
        if(self.cells[0][2].value==symbol):
            if (self.cells[1][2].value==self.cells[0][2].value and self.cells[2][2].value==self.cells[0][2].value):
                return True
            if(self.cells[1][1].value==self.cells[0][2].value and self.cells[2][0].value==self.cells[0][2].value):
                return True
        if(self.cells[1][0].value==symbol):
            if(self.cells[1][1].value==self.cells[1][0].value and self.cells[1][2].value==self.cells[1][0].value):
                return True
        if(self.cells[2][0].value==symbol):
            if(self.cells[2][1].value==self.cells[2][0].value and self.cells[2][2].value==self.cells[2][2].value):
                return True
        return False

    def isEmpty(self,x,y):
        if(self.cells[x][y].value=='p'):
            return True
        else:
            return False

    def putSymbol(self,x,y,symbol):
        self.cells[x][y].value=symbol

    def randomEmptyCell(self):
        for i in range(0,3):
            for j in range(0,3):
                if self.cells[i][j].value=='p':
                    return (i,j)

    def show(self):
        for i in range(0,3):
            output=''
            for j in range(0,3):
                output=output+(self.cells[i][j].value+'')
            output=output+'\n'
            print('\n')
            print(output)

class Cell:
    def __init__(self):
        self.value='p'

def main():
    field=Field()
    player1=Human(field,'X')
    player2=Computer(field,'O')
    g=Game(player1,player2)
    g.startGame()

main()