"""DZ - автостоянка, 5 мест 10 машин
машина проверяет, если есть место, становиться. Если мест нет - ждет.
"""
"""
! 10 скрипачей, 5 скрипок, 5 смычков.
print: Скрипач name играет
"""
#deadlock - 2 потока захватывают по одному mutex, оба потока видят, что mutex'ы заняты - ждут. Простой
#livelock - 2 потока захватывают по одному mutex, оба видят, что mutex'ы заняты - оба освобождают свои mutex'ы. Работа в холостую
import threading
class Port:
    def __init__(self,capacity):
        self.capacity=capacity
        self.size=0
        self.lis=[]
    """
    def __init__(self,prichal):
        self.prichal=prichal
        self.size=0
        self.free_prich=[]
    """

    def add(self,subject):
        if (self.size<self.capacity):
            self.lis.append(subject)
            self.size+=1

    def remove(self):
        if(self.size!=0):
            self.size-=1
            return self.lis.pop(0)
        else:
            return None

class Prichal:
    def __init__(self,capacity):
        self.capacity=capacity
        self.size=0
        self.list=[]

    def add(self,subjectp):
        if(self.size<self.capacity):
            self.list.append(subjectp)
            self.size+=1

    def remove(self):
        if(self.size!=0):
            self.size-=1
            return self.list.pop(0)
        else:
            return None

class Ship_take(threading.Thread):
    def __init__(self,port,prichal,mutex,name):
        threading.Thread.__init__(self)
        self.port=port
        self.prichal=prichal
        self.mutex=mutex
        self.name=name

    def run(self):
        while(True):
            self.mutex.acquire() #захват блокировки mutex
            while(self.port.size==self.port.capacity):
                self.mutex.wait() #освобождает захват mutex !только после acquire ! только в while

            subject=object()
            self.port.add(subject)

            print('#######################')
            print('#Ship_t in Port: '+self.name)

            while(self.prichal.size!=0):
                self.mutex.wait()

            subjectp=object()
            print('#'+ self.name +' stay in prichal')

            self.prichal.remove()
            print(self.name+"leave prichal")
            self.port.remove()
            print('#'+ self.name +' leaving port')
            print('#######################\n')

            self.mutex.notifyAll() #стукнули в стену
            self.mutex.release()


class Ship_put(threading.Thread):
    def __init__(self,port,prichal,mutex,name):
        threading.Thread.__init__(self)
        self.port=port
        self.prichal=prichal
        self.mutex=mutex
        self.name=name


    def run(self):
        while(True):
            self.mutex.acquire()
            while(self.port.size==self.port.capacity):
                self.mutex.wait()

            subject=object()
            self.port.add(subject)
            print('#######################')
            print('#Ship_p in Port: '+self.name)
            while(self.prichal.size==self.prichal.capacity):
                self.port.remove(subject)
                print("#"+self.name+" leave prichal, because absent space")
                self.mutex.notifyAll()
                self.mutex.release()

            subjectp=object()
            self.prichal.add(subjectp)

            print('#'+ self.name +' stay in prichal')
            print("#"+self.name+" leave prichal")

            self.port.remove()

            print('#'+ self.name +' leaving port')
            print('#######################\n')

            self.mutex.notifyAll() #стукнули в стену
            self.mutex.release()


def main():
    port=Port(3)
    prichal=Prichal(5)
    mutex=threading.Condition()
    s1=Ship_put(port,prichal,mutex,'BMW')
    s2=Ship_put(port,prichal,mutex,'Porshe')
    s3=Ship_put(port,prichal,mutex,'Lexus')
    s4=Ship_put(port,prichal,mutex,'Lambargine')
    s5=Ship_put(port,prichal,mutex,'Toyota')
    s6=Ship_take(port,prichal,mutex,'Volvo')
    s7=Ship_take(port,prichal,mutex,'Wolksvagen')
    s8=Ship_take(port,prichal,mutex,'Alpha Romeo')
    s9=Ship_take(port,prichal,mutex,'Ford')
    s10=Ship_take(port,prichal,mutex,'Чайка')
    s1.start()
    s2.start()
    s3.start()
    s4.start()
    s5.start()
    s6.start()
    s7.start()
    s8.start()
    s9.start()
    s10.start()
    s1.join()
    s2.join()
    s3.join()
    s4.join()
    s5.join()
    s6.join()
    s7.join()
    s8.join()
    s9.join()
    s10.join()

main()