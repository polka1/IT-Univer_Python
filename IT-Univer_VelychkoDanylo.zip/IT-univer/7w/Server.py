import socket
import threading

class ClientHandler(threading.Thread):
    def __init__(self,client_sock):
        threading.Thread.__init__(self)
        self.client_sock=client_sock

    def run(self):
        client_message=self.client_sock.recv(1024).decode()
        client_message=client_message+' from server'
        self.client_sock.send(client_message.encode())
        self.client_sock.close()

def main():
    serv_sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    serv_sock.bind(('0.0.0.0', 55555))
    serv_sock.listen(5)#бэклок\ макс клиентов
    while(True):
        client_sock,addr=serv_sock.accept()#обязательно 2 переменне, тк кортеж 
        print(addr)
        client_thread=ClientHandler(client_sock)
        client_thread.start()

main()
