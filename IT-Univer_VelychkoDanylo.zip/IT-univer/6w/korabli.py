"""DZ - автостоянка, 5 мест 10 машин
машина проверяет, если есть место, становиться. Если мест нет - ждет.
"""
"""
! 10 скрипачей, 5 скрипок, 5 смычков.
print: Скрипач name играет
"""
#deadlock - 2 потока захватывают по одному mutex, оба потока видят, что mutex'ы заняты - ждут. Простой
#livelock - 2 потока захватывают по одному mutex, оба видят, что mutex'ы заняты - оба освобождают свои mutex'ы. Работа в холостую
import threading
class Port:
    def __init__(self,capacity):
        self.capacity=capacity
        self.size=0
        self.lis=[]
        for i in range(0,self.capacity):
            self.lis.append(None)
        self.prichals=[]
        for i in range(0,self.capacity):
            p=Prichal(5)
            self.prichals.append(p)
    """
    def __init__(self,prichal):
        self.prichal=prichal
        self.size=0
        self.free_prich=[]
    """

    def add(self,subject):
        if (self.size<self.capacity):
            #self.lis.append(subject)

            for i in range(0,self.capacity):
                if self.lis[i]==None:
                    self.lis[i]=subject
                    self.size+=1
                    return i


    def remove(self,subject):
        if(self.size!=0):
            self.size-=1
            for i in range(0,self.capacity):
                if self.lis[i]==subject:
                    self.lis[i]=None
                    return

class Prichal:
    def __init__(self,capacity):
        self.capacity=capacity
        self.size=0
        self.list=[]

    def add(self,subjectp):
        if(self.size<self.capacity):
            self.list.append(subjectp)
            self.size+=1

    def remove(self):
        if(self.size!=0):
            self.size-=1
            return self.list.pop(0)
        else:
            return None

class Ship_take(threading.Thread):
    def __init__(self,port,mutex,name):
        threading.Thread.__init__(self)
        self.port=port
        #self.prichal=prichal
        self.mutex=mutex
        self.name=name

    def run(self):
        while(True):
            self.mutex.acquire() #захват блокировки mutex
            while(self.port.size==self.port.capacity -1):
                self.mutex.wait() #освобождает захват mutex !только после acquire ! только в while

            number_prichal=self.port.add(self)

            print('#######################')
            print('#Ship_t in Port: '+self.name)
            subject=None
            if (self.port.prichals[number_prichal].size!=0):
               subject=self.port.prichals[number_prichal].remove()
               self.port.remove(self)
               self.mutex.notifyAll()
               self.mutex.release()

            else:
                self.port.remove(self)
                self.mutex.notifyAll()
                self.mutex.release()
                continue


            print('#'+ self.name +' leaving port')
            print('#######################\n')
            break

class Ship_put(threading.Thread):
    def __init__(self,port,mutex,name):
        threading.Thread.__init__(self)
        self.port=port
        self.mutex=mutex
        self.name=name


    def run(self):
        while(True):
            self.mutex.acquire()
            while(self.port.size==self.port.capacity-1):
                self.mutex.wait()

            number_prichal=self.port.add(self)
            print('#######################')
            print('#Ship_p in Port: '+self.name)
            if(self.port.prichals[number_prichal].size==self.port.prichals[number_prichal].capacity):
                self.port.remove(self)
                self.mutex.notifyAll()
                self.mutex.release()
                continue
            else:
                subject=object()
                self.port.prichals[number_prichal].add(subject)
                self.port.remove(self)
                self.mutex.notifyAll()
                self.mutex.release()

            print('#'+ self.name +' leaving port')
            print('#######################\n')
            break


def main():
    port=Port(3)
    mutex=threading.Condition()
    s1=Ship_put(port,mutex,'BMW')
    s2=Ship_put(port,mutex,'Porshe')
    s3=Ship_put(port,mutex,'Lexus')
    s4=Ship_put(port,mutex,'Lambargine')
    s5=Ship_put(port,mutex,'Toyota')
    s6=Ship_take(port,mutex,'Volvo')
    s7=Ship_take(port,mutex,'Wolksvagen')
    s8=Ship_take(port,mutex,'Alpha Romeo')
    s9=Ship_take(port,mutex,'Ford')
    s10=Ship_take(port,mutex,'Чайка')
    s1.start()
    s2.start()
    s3.start()
    s4.start()
    s5.start()
    s6.start()
    s7.start()
    s8.start()
    s9.start()
    s10.start()
    s1.join()
    s2.join()
    s3.join()
    s4.join()
    s5.join()
    s6.join()
    s7.join()
    s8.join()
    s9.join()
    s10.join()

main()