"""DZ - автостоянка, 5 мест 10 машин
машина проверяет, если есть место, становиться. Если мест нет - ждет.
"""
"""
! 10 скрипачей, 5 скрипок, 5 смычков.
print: Скрипач name играет
"""
#deadlock - 2 потока захватывают по одному mutex, оба потока видят, что mutex'ы заняты - ждут. Простой
#livelock - 2 потока захватывают по одному mutex, оба видят, что mutex'ы заняты - оба освобождают свои mutex'ы. Работа в холостую
import threading
class Parking:
    def __init__(self,capacity):
        self.capacity=capacity
        self.size=0
        self.lis=[]

    def add(self,subject):
        if (self.size<self.capacity):
            self.lis.append(subject)
            self.size+=1

    def remove(self):
        if(self.size!=0):
            self.size-=1
            return self.lis.pop(0)
        else:
            return None

class Cars(threading.Thread):
    def __init__(self,parking,mutex,name):
        threading.Thread.__init__(self)
        self.parking=parking
        self.mutex=mutex
        self.name=name

    def run(self):
        while(True):
            self.mutex.acquire() #захват блокировки mutex
            while(self.parking.size==self.parking.capacity):
                self.mutex.wait() #освобождает захват mutex !только после acuire ! только в while

            subject=object()
            self.parking.add(subject)

            print('#######################')
            print('#1 car put in parking: '+self.name)
            print('#'+ self.name +' go on stay on parking')

            self.parking.remove()
            print('#'+ self.name +' leaving the parking')
            print('#######################\n')

            self.mutex.notifyAll() #стукнули в стену
            self.mutex.release()

"""
class Consumer(threading.Thread):
    def __init__(self,tumb,mutex,name):
        threading.Thread.__init__(self)
        self.tumb=tumb
        self.mutex=mutex
        self.name=name

    def run(self):
        while(True):
            self.mutex.acquire()
            while(self.tumb.size==0):
                self.mutex.wait()

            self.tumb.remove()
            print('we remove from the tumd: '+self.name)
            self.mutex.notifyAll()
            self.mutex.release()
"""

def main():
    parking=Parking(5)
    mutex=threading.Condition()
    c1=Cars(parking,mutex,'BMW')
    c2=Cars(parking,mutex,'Porshe')
    c3=Cars(parking,mutex,'Lexus')
    c4=Cars(parking,mutex,'Lambargine')
    c5=Cars(parking,mutex,'Toyota')
    c6=Cars(parking,mutex,'Volvo')
    c7=Cars(parking,mutex,'Wolksvagen')
    c8=Cars(parking,mutex,'Alpha Romeo')
    c9=Cars(parking,mutex,'Ford')
    c10=Cars(parking,mutex,'Чайка')
    c1.start()
    c2.start()
    c3.start()
    c4.start()
    c5.start()
    c6.start()
    c7.start()
    c8.start()
    c9.start()
    c10.start()
    c1.join()
    c2.join()
    c3.join()
    c4.join()
    c5.join()
    c6.join()
    c7.join()
    c8.join()
    c9.join()
    c10.join()

main()