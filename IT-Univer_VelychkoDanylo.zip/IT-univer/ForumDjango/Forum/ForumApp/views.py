from django.shortcuts import render
from ForumApp.forms import LoginForm,RegistrationForm
from ForumApp.models import *

def home(request):
    return render(request,"home.html",{})

def login(request):
    login_form=LoginForm()
    dic={'login_form':login_form}
    return render(request,"login.html",dic)

def loginHandler(request):
    login_data=LoginForm(request.GET)
    if login_data.is_valid():
        login=login_data.cleaned_data['login']
        user_password=login_data.cleaned_data['password']
        user=User.objects.filter(nick=login,password=user_password).first()
        #select *  from users where nick=login and password=user_password
        if(user==None):
            return render(request,"home.html",{})
        else:
            role=user.id_role
            if(role.name=="admin"):
                request.session['user_role']="admin"
                return render(request,"adminPage.html",{})
            else:
                request.session['user_role']="user"
                request.session['user_name']=user.nick
                sections=Section.objects.all()
                dic={"sections":sections}
                return render(request,"forums.html",dic)

    else:
        return render(request,"home.html",{})


def userListShow(request):
    if(request.session.get("user_role",None)=="admin"):
        users=User.objects.all()
        users_nick_emails=[]
        for user in users:
            users_nick_emails.append((user.nick,user.e_mail))

        dic={"nicks_emails":users_nick_emails}
        return render(request,"adminUsers.html",dic)
    else:
        return render(request,"home.html",{})

def deleteUser(request):
    if(request.session.get("user_role",None)=="admin"):
        user_nick=request.GET.get('nick')
        User.objects.filter(nick=user_nick).first().delete()
        userListShow(request)

    else:
        return render(request,"home.html",{})

def showPosts(request):
    if(request.session.get("user_role",None)=="admin"):
        user_nick=request.GET.get('nick')
        posts=Post.objects.filter(id_user__nick=user_nick)
        #select * from posts join user on user.id=id_user where user.nick=user_nick
        messages=[]
        for post in posts:
            messages.append(post.message)

        dic={"messages":messages}
        return render(request,"posts.html",dic)
    else:
        return render(request,"home.html",{})


def deletePosts(request):
       if(request.session.get("user_role",None)=="admin"):
           post=request.GET.get('post')
           Post.objects.filter(message=post).first().delete()
           showPosts(request)
       else:
          return render(request,"home.html",{})

def registration(request):
    registration_form=RegistrationForm()
    dic={'registration_form':registration_form}
    return render(request,"registration.html",dic)

def registrationHandler(request):
    registration_data=RegistrationForm(request.GET)
    if registration_data.is_valid():
        user_nick=registration_data.cleaned_data['nick']
        user_email=registration_data.cleaned_data['email']
        user_password=registration_data.cleaned_data['password']
        r=Role.objects.filter(name='user').first()
        u=User(nick=user_nick, e_mail=user_email,password=user_password,id_role=r)
        u.save()
        return render(request,"home.html",{})

    else:
        return render(request,"home.html",{})

def addUserSection(request):
  if(request.session.get("user_role",None)!=None):
    section_name=request.GET['section_name']
    s=Section(name=section_name)
    s.save()
    sections=Section.objects.all()
    forumsdic={"sections":sections}
    return render(request,"forums.html",forumsdic)
  else:
    return render(request,"home.html",{})

def userSectionHandler(request):
   if(request.session.get("user_role",None)!=None):
    section_name=request.GET['section']
    themes=Theme.objects.filter(id_section__name=section_name)
    dic={'themes':themes,'section':section_name}
    return render(request,'themes.html',dic)
   else:
    return render(request,"home.html",{})

def addUserTheme(request):
    if(request.session.get("user_role",None)!=None):
        section_name=request.GET['section']
        theme_name=request.GET['theme_name']
        s=Section.objects.filter(name=section_name).first()
        user_nick=request.session.get("user_name")
        u=User.objects.filter(nick=user_nick).first()
        t=Theme(name=theme_name,id_user=u,id_section=s)
        t.save()
        themes=Theme.objects.filter(id_section__name=section_name)
        dic={'themes':themes,'section':section_name}
        return render(request,'themes.html',dic)
    else:
        return render(request,"home.html",{})

def themeUserHandler(request):
    if(request.session.get("user_role",None)!=None):
        theme_name=request.GET['theme']
        posts=Post.objects.filter(id_theme__name=theme_name)
        output=''
        for post in posts:
            output+=post.id_user.nick+' '+str(post.time_creation)+' '+post.message+'\n'
        dic={'theme':theme_name,'posts':output}
        return render(request,"chat.html",dic)
    else:
        return render(request,"home.html",{})

def addUserMessage(request):
    if(request.session.get("user_role",None)!=None):
       theme_name=request.GET['theme']
       user_name=request.session.get("user_name")
       post_message=request.GET['message']
       t=Theme.objects.filter(name=theme_name).first()
       u=User.objects.filter(nick=user_name).first()
       p=Post(message=post_message,id_theme=t,id_user=u)
       p.save()
       posts=Post.objects.filter(id_theme__name=theme_name)
       output=''
       for post in posts:
            output+=post.id_user.nick+' '+str(post.time_creation)+' '+post.message+'\n'
       dic={'theme':theme_name,'posts':output}
       return render(request,"chat.html",dic)
    else:
       return render(request,"home.html",{})

def forums(request):
    return render(request,"forums.html",{})

