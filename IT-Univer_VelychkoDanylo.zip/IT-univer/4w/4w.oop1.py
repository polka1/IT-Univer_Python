class Bunch:
    def __init__(self):
        self.flowers=[]
        self.accessory=None

    def add(self,flower):
        self.flowers.append(flower)

    def addA(self,accsessory):
        self.accessory=accsessory

    def totalPrice(self):
        total=0
        for flower in self.flowers:
            total=total+flower.price

        total=total+self.accessory.price
        return total

class Flower:
    def __init__(self,price):
        self.price=price

class Accessory:
    def __init__(self,price):
        self.price=price

def main():
    flower1=Flower(10)
    flower2=Flower(20)
    flower3=Flower(30)
    accessory1=Accessory(15)
    bunch=Bunch()
    bunch.add(flower1)
    bunch.add(flower2)
    bunch.add(flower3)
    bunch.addA(accessory1)
    resultPrice=bunch.totalPrice()
    print(resultPrice)
main()
