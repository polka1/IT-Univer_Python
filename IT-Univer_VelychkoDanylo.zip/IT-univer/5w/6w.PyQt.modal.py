import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import Qt
from PyQt5 import uic
from PyQt5 import QtCore

class MainForm(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        #3 обязательные строки
        Form, Base = uic.loadUiType('main_form.ui')
        self.myform=Form()
        self.myform.setupUi(self)
        self.myform.pushButton_2.clicked.connect(Qt.qApp.quit)
        self.myform.pushButton.clicked.connect(self.on_clicked)


    def on_clicked(self):
        mytext=self.myform.textEdit.toPlainText() #забрали
        output=ModalWindow(self)
        output.form.label.setText(mytext) #отдали
        output.show()

class ModalWindow(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.WindowSystemMenuHint)    #запретить юзать мэин
        self.setWindowModality(QtCore.Qt.WindowModal)
        Form, Base = uic.loadUiType('modal_form.ui')
        self.form=Form()
        self.form.setupUi(self)
        self.form.pushButton.clicked.connect(Qt.qApp.quit)


def main():
    if __name__ == '__main__':
        app=QApplication(sys.argv)
        window=MainForm()
        window.show()
        sys.exit(app.exec_())
main()

