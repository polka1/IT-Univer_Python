# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Post',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('message', models.CharField(max_length=1000)),
                ('time_creation', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.CreateModel(
            name='Role',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Section',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Theme',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=30)),
                ('id_section', models.ForeignKey(to='ForumApp.Section')),
            ],
        ),
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('nick', models.CharField(max_length=30)),
                ('e_mail', models.EmailField(max_length=1000)),
                ('password', models.CharField(max_length=30)),
                ('id_role', models.ForeignKey(to='ForumApp.Role')),
            ],
        ),
        migrations.AddField(
            model_name='theme',
            name='id_user',
            field=models.ForeignKey(to='ForumApp.User'),
        ),
        migrations.AddField(
            model_name='post',
            name='id_theme',
            field=models.ForeignKey(to='ForumApp.Theme'),
        ),
        migrations.AddField(
            model_name='post',
            name='id_user',
            field=models.ForeignKey(to='ForumApp.User'),
        ),
    ]
