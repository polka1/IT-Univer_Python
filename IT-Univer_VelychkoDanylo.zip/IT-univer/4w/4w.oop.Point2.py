import math
def dist(p1,p2):
    d=math.sqrt((p1.x-p2.x)**2+(p1.y-p2.y)**2)
    return d


class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y




class Circle(Point):
    def __init__(self,x,y,radius):
        Point.__init__(self,x,y)
        self.radius=radius

class Circle2:
    def __init__(self,center,radius):
        self.center=center
        self.radius=radius



def main():
    p1=Point(10,20)
    p2=Point(30,40)
    res=dist(p1,p2)
    print(res)
    c1=Circle(50,60,100)
    c2=Circle(70,80,90)
    res1=dist(c1,c2)
    print(res1)

    c3=Circle2(p1,400)
    c4=Circle2(p2,600)
    res2=dist(c3,c4)
    print (res2)

main()