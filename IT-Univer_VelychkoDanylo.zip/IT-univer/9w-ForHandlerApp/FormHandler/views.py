from django.shortcuts import render

def index(request):
    dic={}
    return render(request, "index.html", dic)


def indexHandler(request):
    #value=request.COOKIES.get('name',None)
    value=request.session.get('name', None)
    if (value==None):
        value=request.GET.get("myname")
        dic = {'user_name': value}
        response=render(request,"answer.html",dic)
        #response.set_cookie("name",value, 30)
        request.session["name" ] = value
        request.session.set_expiry(100)
        return response

    dic = {'user_name': value}
    return render(request,"answer.html",dic)
