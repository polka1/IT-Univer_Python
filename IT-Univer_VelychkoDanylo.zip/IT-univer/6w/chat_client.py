import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import Qt
from PyQt5 import uic
from PyQt5 import QtCore

class MainForm(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        #3 обязательные строки
        Form, Base = uic.loadUiType('chat_client.ui')
        self.myform=Form()
        self.myform.setupUi(self)
        self.myform.exit_button.clicked.connect(Qt.qApp.quit)
        self.myform.send_msg_button.clicked.connect(self.on_clicked)


    def on_clicked(self):
        msg_log=[]
        mytext=self.myform.send_msg_display.toPlainText() #забрали
        msg_log=msg_log.append(mytext)
        output=MainForm(self)
        output.myform.display_msg.setText('\n'+mytext) #отдали
        output.show()
"""
class ModalWindow(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.setWindowFlags(QtCore.Qt.Dialog | QtCore.Qt.WindowSystemMenuHint)    #запретить юзать мэин
        self.setWindowModality(QtCore.Qt.WindowModal)
        Form, Base = uic.loadUiType('modal_form.ui')
        self.form=Form()
        self.form.setupUi(self)
        self.form.pushButton.clicked.connect(Qt.qApp.quit)
"""

def main():
    if __name__ == '__main__':
        app=QApplication(sys.argv)
        window=MainForm()
        window.show()
        sys.exit(app.exec_())
main()

