import math
class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y

    def distance(self):
        d=math.sqrt(self.x*self.x+self.y*self.y)
        return d

class Circle(Point):
    def __init__(self,x,y,radius):
        Point.__init__(self,x,y)
        self.radius=radius

def main():
    p=Point(10,20)
    c=Circle(30,40,100)
    print(p.__dict__)
    print(c.__dict__)
    res=c.distance()

main()
m89282504