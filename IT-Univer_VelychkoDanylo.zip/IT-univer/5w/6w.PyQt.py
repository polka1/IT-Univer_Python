import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import Qt
from PyQt5 import uic
from PyQt5 import QtCore


class Myform(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        # 3 обязательные строки

        Form, Base = uic.loadUiType('form.ui')
        self.testform = Form()  # одно и тоже, что и на строку выше
        self.testform.setupUi(self)

        self.testform.push1.clicked.connect(self.on_clicked)
        self.testform.push2.clicked.connect(self.on_clicked)
        self.testform.push3.clicked.connect(self.on_clicked)

    def on_clicked(self):
        button = self.sender()
        name = button.text()
        self.testform.label.setText(name)


def main():
    if __name__ == '__main__':
        app = QApplication(sys.argv)
        window = Myform()
        window.show()
        sys.exit(app.exec_())


main()
