from django.conf.urls import include, url
from django.contrib import admin
from ForumApp.views import *

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$',home),
    url(r'^login$',login),
    url(r'^loginHandler$',loginHandler),
    url(r'^userlist$',userListShow),
    url(r'^delete$',deleteUser),
    url(r'^posts$',showPosts),
    url(r'^deletePosts$',deletePosts),
    url(r'^registration$',registration),
    url(r'^registrationHandler$',registrationHandler),
    url(r'^addUserSection$',addUserSection),
    url(r'^userSectionHandler$',userSectionHandler),
    url(r'^addUserTheme$',addUserTheme),
    url(r'^themeUserHandler$',themeUserHandler),
    url(r'^addUserMessage$',addUserMessage),
    url(r'^forums$',forums),



]
