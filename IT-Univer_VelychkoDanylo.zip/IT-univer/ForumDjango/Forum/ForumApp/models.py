from django.db import models

class Section(models.Model):
    name=models.CharField(max_length=30)

class Role(models.Model):
    name=models.CharField(max_length=30)

class User(models.Model):
    nick=models.CharField(max_length=30)
    e_mail=models.EmailField(max_length=1000)
    password=models.CharField(max_length=30)
    id_role=models.ForeignKey(Role,on_delete=models.CASCADE)

class Theme(models.Model):
    name=models.CharField(max_length=30)
    id_user=models.ForeignKey(User,on_delete=models.CASCADE)
    id_section=models.ForeignKey(Section,on_delete=models.CASCADE)

class Post(models.Model):
    message=models.CharField(max_length=1000)
    id_theme=models.ForeignKey(Theme,on_delete=models.CASCADE)
    id_user=models.ForeignKey(User,on_delete=models.CASCADE)
    time_creation=models.DateTimeField(auto_now=True)


