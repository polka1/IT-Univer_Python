import sys
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import Qt
from PyQt5 import uic
from PyQt5 import QtCore

class MyForm(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        #3 обязательные строки
        Form,Base = uic.loadUiType('MyForm.ui')
        self.myform=Form() #одно и тоже, что и на строку выше
        self.myform.setupUi(self)
        self.myform.Exit.clicked.connect(Qt.qApp.quit)
        self.myform.Ok.clicked.connect(self.write)

    def write(self):
        text=self.myform.login_edit.text()
        text=text + self.myform.pass_edit.text()
        self.myform.label.setText(text)

def main():
    if __name__=='__main__':
        app=QApplication(sys.argv)
        window=MyForm()
        window.show()
        sys.exit(app.exec_())
main()