import sys
import re
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import Qt
from PyQt5 import uic
from PyQt5 import QtCore
class Calc(QWidget):
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        Form,Base = uic.loadUiType('calc.ui')
        self.myform=Form() #одно и тоже, что и на строку выше
        self.myform.setupUi(self)
        self.myform.num1.clicked.connect(self.num1)
"""
        self.myform.num2.clicked.connect(self.num2)
        self.myform.num3.clicked.connect(self.num3)
        self.myform.num4.clicked.connect(self.num4)
        self.myform.num5.clicked.connect(self.num5)
        self.myform.num6.clicked.connect(self.num6)
        self.myform.num7.clicked.connect(self.num7)
        self.myform.num8.clicked.connect(self.num8)
        self.myform.num9.clicked.connect(self.num9)
        self.myform.plus.clicked.connect(self.plus)
        self.myform.minus.clicked.connect(self.minus)
        self.myform.delit.clicked.connect(self.delit)
        self.myform.umnogit.clicked.connect(self.umnogit)
"""
    def num1(self):
        print=self.myform.label.text()

#parser=re.findall("[\d]+([\+,\-,\*,\/,](1))([\d]+)"


def main():
    if __name__=='__main__':
        app=QApplication(sys.argv)
        window=Calc()
        window.show()
        sys.exit(app.exec_())
main()