#pyqt ответы

import mysql.connector

def main():
    conn=mysql.connector.connect(user='root',
                                 password='4LSforMYSQL',
                                          host='lockalhost',
                                 database='ITuniver')
    cursor=conn.cursor()
    sql='select * from clients'
    cursor.execute(sql)
    conn.commit()#замена копии на оригенал


    for row in cursor:
        print(str(row[0])+" " +row[1]+" "+row[2])

main()