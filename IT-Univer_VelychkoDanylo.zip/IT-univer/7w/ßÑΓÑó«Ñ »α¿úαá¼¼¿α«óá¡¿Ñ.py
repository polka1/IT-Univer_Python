"""
1969 оборонная программа США на случай ядерной войны - интернет
TCP/IP
UDP -без гарантии доставки (видео онлайн)
"""
#MirrorServer
import socket
def main():
    sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM) #socket.SOCK_DGRAM - UDP
    sock.connect(('127.0.0.1', 55555))
    message='Hello server'
    sock.send(message.encode())
    answer=sock.recv(1024).decode()#получает сообщения
    print(answer)
    sock.close()

main()