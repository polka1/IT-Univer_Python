import threading
import time
class Violin:
    pass


class QueuViolins:
    def __init__(self,capacity):
        self.capacity=capacity
        self.violins=[]
        self.size=0
        for i in range(0,self.capacity):
            self.size+=1
            v=Violin()
            self.violins.append(v)


    def add(self,violin):
        self.violins.append(violin)
        self.size+=1

    def remove(self):
        self.size-=1
        return self.violins.pop(0)

class Bow:
    pass

class QueuBow:
    def __init__(self,capacity):
        self.capacity=capacity
        self.bows=[]
        self.size=0
        for i in range(0,self.capacity):
            self.size+=1
            v=Bow()
            self.bows.append(v)


    def add(self,bow):
        self.bows.append(bow)
        self.size+=1

    def remove(self):
        self.size-=1
        return self.bows.pop(0)

class Violinist (threading.Thread):
    def __init__(self,queue_violins,mutex_violins,queue_bows,mutex_bows,name):
        threading.Thread.__init__(self)
        self.name=name
        self.queue_violins=queue_violins
        self.mutex_violins=mutex_violins
        self.queue_bows=queue_bows
        self.mutex_bows=mutex_bows

    def run(self):
        while(True):
            self.mutex_violins.acquire()
            while(self.queue_violins.size==0):
                self.mutex_violins.wait()

            violin=self.queue_violins.remove()
            self.mutex_violins.release()

            self.mutex_bows.acquire()
            while(self.queue_bows.size==0):
                self.mutex_bows.wait()

            bow=self.queue_bows.remove()
            self.mutex_bows.release()

            print('The violinist '+self.name+" is playing")
            time.sleep(1)
            self.mutex_violins.acquire()
            self.queue_violins.add(violin)
            self.mutex_violins.notifyAll() # сообщили всем что скрипка свободно
            self.mutex_violins.release()
            self.mutex_bows.acquire()
            self.queue_bows.add(violin)
            self.mutex_bows.notifyAll()
            self.mutex_bows.release()
            time.sleep(2)

def main():
    violins=QueuViolins(4)
    bows=QueuBow(2)
    mutex_violins=threading.Condition()
    mutex_bows=threading.Condition()
    v1=Violinist(violins,mutex_violins,bows,mutex_bows,'v1')
    v2=Violinist(violins,mutex_violins,bows,mutex_bows,'v2')
    v3=Violinist(violins,mutex_violins,bows,mutex_bows,'v3')
    v4=Violinist(violins,mutex_violins,bows,mutex_bows,'v4')
    v1.start()
    v2.start()
    v3.start()
    v4.start()
    v1.join()
    v2.join()
    v3.join()
    v4.join()

main()